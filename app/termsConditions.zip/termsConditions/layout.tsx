 

export default async function ContactLayout({
  children,
}: any) {
   

  return (
    <div  className="" >
     {children}
    </div>
  )
}
